<?php 
define('KOD_VERSION','2.73');