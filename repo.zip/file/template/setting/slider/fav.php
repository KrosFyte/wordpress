<div class='h1'><i class="font-icon icon-star"></i><?php echo $L['setting_fav'];?></div>
<div class="section fav">
	<table id='list' align="center" border=0 cellspacing=0 cellpadding=0 ></table>
	<a href="#" class='add'><i class="font-icon icon-plus"></i><?php echo $L['button_add'];?></a>
</div>
